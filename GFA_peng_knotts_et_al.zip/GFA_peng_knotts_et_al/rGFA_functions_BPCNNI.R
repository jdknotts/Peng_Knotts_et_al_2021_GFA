##########       robustGFA         ##########
#####  Author:       Henry Yeh, Ph.D.   #####
#####  Contributors: Maria Puhl, Ph.D.  #####
#####                Martin Paulus, MD. #####
#####                JD Knotts, Ph.D. #####
#####  The following functions are developed to combine multiple   #####
#####  replicates of GFA and obtain robust components and loadings #####

W_heatmap <- function(W_DxK, varIdx.by.block, block.names){
  gr <- varIdx.by.block; M <- length(gr)
  names(gr) <- block.names
  gr1 <- c(0, cumsum(sapply(gr, length)))
  names(gr1) <- c(names(gr), "NA")
  D <- nrow(W_DxK)
  K <- ncol(W_DxK)

  mar <- c(6,4,4,6)
  par(mar=mar)
  cols <- colorRampPalette(c("orange","red","white","blue","cyan"))(19)
  if(any(is.na(W_DxK))) cols <- colorRampPalette(c("orange","red","#DDDDDD","blue","cyan"))(19)
  M <- max(abs(W_DxK), na.rm=T)
  breaks <- seq(-M, M, length=20)

  title <- c("Matrix W^T", "Factors", "Features")

  if (K==1){
    image(as.matrix(W_DxK[,1]), col=cols, breaks=breaks, axes=F, main=title[1],
          xlab="", ylab="")
  } else {
    image(1:D, 1:K, W_DxK[,K:1], col=cols, breaks=breaks, axes=F, main=title[1],
          xlab="",ylab="")
  }
  title(xlab=title[3],line=mar[1]-1)
  title(ylab=title[2],line=mar[2]-1)
  box()
  par(las=2)
  if (K == 1){
    axis(1, (0:(D-1))/D, rownames(W_DxK), cex.axis=D^(-1/5))
    axis(2, K:1, colnames(W_DxK), cex.axis=K^(-1/5))
  } else {
    axis(1, 1:D, rownames(W_DxK), cex.axis=D^(-1/5))
    axis(2, K:1, colnames(W_DxK), cex.axis=K^(-1/5))
  }

  #Grouping
  par(xpd=T)
  mu <- gr1[-1]/2+gr1[-length(gr1)]/2
  N <- K
  for(i in 1:length(mu)) {
    if (K ==1){
      if(i!=length(mu)) lines(rep(gr1[i+1]-0.5,2)/D, c(-1, 1.05), lwd=2)
      text(mu[i]/D,1.065,names(gr1)[i])
    } else {
      if(i!=length(mu)) lines(rep(gr1[i+1]+1/2,2), c(.5, N*1.03+.5), lwd=2)
      text(mu[i],N*1.03+.5,names(gr1)[i])
    }
  }
  #Colorbar
  n <- length(cols)
  if (K==1){
    cba <- 1.1
    cbw <- 1/D
    for(i in 1:n){
      polygon(c(0,cbw,cbw,0)+cba, (c(0,0,N/n,N/n)+N*(i-1)/n+1/2)-1,
              col=cols[i], border=NA)
    }
    #Colorbar: axis
    lines(rep(cba+cbw,2),c(0,N)+1/2-1)
    m <- 10^floor(log10(M))
    m <- floor(M/m)*m
    for(l in c(-m,0,m)) {
      ly <- N*(l/M/2+.5)+1/2-1
      lines(cba+cbw-c(cbw,-cbw)/5, rep(ly,2))
      text(cba+cbw*2.5+0.02,ly,l)
    }
  } else {
    cba <- D + 1/2 + D/60
    cbw <- D/40
    for(i in 1:n){
      polygon(c(0,cbw,cbw,0)+cba, c(0,0,N/n,N/n)+N*(i-1)/n+1/2,
              col=cols[i], border=NA)
    }
    #Colorbar: axis
    lines(rep(cba+cbw,2),c(0,N)+1/2)
    m <- 10^floor(log10(M)); m <- floor(M/m)*m
    for(l in c(-m,0,m)) {
      ly <- N*(l/M/2+.5)+1/2
      lines(cba+cbw-c(cbw,-cbw)/5, rep(ly,2))
      text(cba+cbw*2.5,ly,l)
    }
  }
  par(xpd=F)
}

##### for data simulation #####
## N: sample size
## tW.list: a list of matrices with K x D_{i} dimension
## sd.noise: SD of random Gaussian noise
data.simu <- function(N, W_DxK, varIdx.by.block, sd.noise){
  B = length(varIdx.by.block)
  K = ncol(W_DxK)
  D = nrow(W_DxK)
  # X <- matrix(rnorm(N*K), N, K) ## 0 score mean not guarantteed
  X <- matrix(NA, N, K)
  for (k in 1:K){
    X[, k] <- rnorm(N) ## each factor (column) has a mean closer to 0
  }
  colnames(X) <- paste0("K", 1:K)
  Y <- X %*% t(W_DxK) + sd.noise*matrix(rnorm(N*D), N, D)
  colnames(Y) <- paste0("V", 1:D)
  Y.list <- list()
  for (b in 1:B){
    Y.list[[b]] <- Y[, varIdx.by.block[[b]]]
  }
  return(list(Y.list=Y.list, X=X))
}

# #### Revise robustComponents() to allow 0 matched factors
# ## Internal function for matching components
# matchComponents <- function(comps, maxK, N, D, corThr, matchThr) {
#   corList <- list()
#   reps <- length(comps)
#   rob <- list(Krobust=0,effect=c(),indices=matrix(NA,reps,0),cor=matrix(NA,reps,0))
#   
#   compStorage <- vector("list",length=reps) #Store the components that can still be used
#   for(rep in 1:reps) compStorage[[rep]] <- which(sapply(comps[[rep]], function(x) {sum(abs(x)) > 0}))
#   
#   for (rep1 in 1:reps) {
#     matching <- vector(length = maxK)
#     sim <- array(NA, dim = c(maxK, reps))
#     matchInd <- matrix(0, nrow = maxK, ncol = reps)
#     
#     for (k1 in compStorage[[rep1]]) {
#       for (rep2 in which(sapply(compStorage, length)>0)) {
#         #Correlation between the two components.
#         #Note that we do not need to use the absolute values, as the correlation is computed in data space.
#         d <- sapply(comps[[rep2]][compStorage[[rep2]]], function(x) cor(c(x), c(comps[[rep1]][[k1]])))
#         sim[k1,rep2] <- max(d)
#         matchInd[k1,rep2] <- compStorage[[rep2]][which.max(d)]
#         if(sim[k1,rep2] < corThr) matchInd[k1,rep2] <- matchInd[k1,rep2]*-1 #Index saved for debugging purposes
#       }
#       
#       if(sum(sim[k1,]>corThr, na.rm=T) >= matchThr*reps) { #Robust component found!
#         # average over all similar components
#         comp <- matrix(0, N, D)
#         for(rep2 in which(matchInd[k1,] > 0)) {
#           comp <- comp + comps[[rep2]][[matchInd[k1,rep2]]]
#           compStorage[[rep2]] <- compStorage[[rep2]][!compStorage[[rep2]]==matchInd[k1,rep2]]
#         }
#         comp <- comp/sum(matchInd[k1,]>0)
#         
#         rob$Krobust <- rob$Krobust + 1
#         rob$effect <- array(c(rob$effect, comp), dim=c(dim(comp),rob$K),
#                             dimnames=list(NA, paste0("V", 1:D),
#                                           paste0("K",1: rob$Krobust)))
#         rob$indices <- cbind(rob$indices, matchInd[k1,])
#         rob$cor <- cbind(rob$cor, sim[k1,])
#       }
#     }
#   }
#   if(rob$Krobust>0){
#     rownames(rob$indices) <- rownames(rob$cor) <- paste0("rep",1:reps)
#     colnames(rob$indices) <- colnames(rob$cor) <- paste0("K",1:rob$Krobust)
#   }
#   return(rob)
# }

##### Compute factor-specific posterior mean of reconstructed data (X*t(W)) #####
pmXW_by_factor <- function(res){ #JD hack, original: pmXW_by_factor <- function(gfa.obj){
  comps <- list()
  for (k in 1:res$K) {
    comp <- crossprod(res$posterior$X[,,k], res$posterior$W[,,k])
    comps[[k]] <- comp / res$opts$iter.saved
  }
  return(comps)
}

##### a function adopted from GFA::matchComponents to match factors #####
matchFactors <- function(comps, maxK, corThr, matchThr){
  reps <- length(comps)
  rob <- list(Krobust=0, indices=matrix(NA,reps,0), cor=matrix(NA,reps,0))
  
  compStorage <- vector("list", length=reps) #Store the components that can still be used
  for(rep in 1:reps) compStorage[[rep]] <- which(sapply(comps[[rep]], function(x) {sum(abs(x)) > 0}))
  
  for (rep1 in 1:reps) {
    sim <- array(NA, dim = c(maxK, reps))
    matchInd <- matrix(0, nrow = maxK, ncol = reps)
    
    for (k1 in compStorage[[rep1]]) {
      for (rep2 in which(sapply(compStorage, length)>0)) {
        #Correlation between the two components.
        #Note that we do not need to use the absolute values, as the correlation is computed in data space.
        d <- sapply(comps[[rep2]][compStorage[[rep2]]], function(x) cor(c(x), c(comps[[rep1]][[k1]])))
        sim[k1,rep2] <- max(d)
        matchInd[k1,rep2] <- compStorage[[rep2]][which.max(d)]
        if(sim[k1,rep2] < corThr) matchInd[k1,rep2] <- matchInd[k1,rep2]*-1 #Index saved for debugging purposes
      }
      
      if(sum(sim[k1, ]>corThr, na.rm=T) - 1 >= matchThr*(reps-1)) { #Robust component found!
        rob$Krobust <- rob$Krobust + 1
        rob$indices <- cbind(rob$indices, matchInd[k1,])
        rob$cor <- cbind(rob$cor, sim[k1,])
        for(rep2 in which(matchInd[k1,] > 0)) {
          compStorage[[rep2]] <- compStorage[[rep2]][!compStorage[[rep2]]==matchInd[k1,rep2]]
        }
      }
    }
  }
  if(rob$Krobust>0){
    rownames(rob$indices) <- rownames(rob$cor) <- paste0("rep",1:reps)
    colnames(rob$indices) <- colnames(rob$cor) <- paste0("K", 1:rob$Krobust)
  }
  return(rob)
}

# a fcuntion to compute MSE b/w observed and reconstructed data matrices for each replicate for 
#   each pair of (corThr, matchThr).
MSE.Grids <- function(Ymtx, maxK, comps, corGrids, matchGrids){
  R = length(comps)
  
  indices <- rep( list(list()), length(corGrids) )
  K.grids <- 
    matrix(NA, nrow=length(corGrids), ncol=length(matchGrids), 
           dimnames=list(corThr=corGrids, matchThr=matchGrids))
  mse <- list(all=NULL, survived=NULL)
  mse$all <- mse$survived <- array(NA, c(length(corGrids), length(matchGrids), R))
  
  for (i in 1:length(corGrids)){
    for (j in 1:length(matchGrids)){
      print(paste(Sys.time(),": ",i,",",j))
      
      tmp <- matchFactors(comps, maxK, corThr=corGrids[i], matchThr=matchGrids[j])
      if(ncol(tmp$indices)>0){
        indices[[i]][[j]] <- tmp$indices
        K.grids[i,j] <- tmp$Krobust # ifelse(tmp$Krobust > max(K.by.rep), K.by.rep, tmp$Krobust)
        if (K.grids[i,j]>0){ # at least 1 factor
          for (r in 1:R){
            ## use all "matched" factors
            indx.use <- tmp$indices[r,]
            yhat <- Reduce("+", comps[[r]][abs(indx.use)])
            mse$all[i,j,r] <- mean((Ymtx-yhat)^2, na.rm=T)
            ## use the "matched" factors surviving corThr
            indx.use <- tmp$indices[r,][tmp$indices[r,] >0]
            yhat <- Reduce("+", comps[[r]][indx.use])
            mse$survived[i,j,r] <- mean((Ymtx-yhat)^2, na.rm=T)
          }
        }
      }
      rm(tmp)
    }
  }
  return(list(K.grids=K.grids, indices=indices, mse=mse))
}

# a function to identify optimal (corThr, matchThr)
optimizeK <- function(K.grids, mse.array){ # c(N.corGrids, N.matchGrids, N.reps)
  reps = dim(mse.array)[3]  
  mse.m <- apply(mse.array, 1:2, mean, na.rm=T)
  mse.m <- matrix(as.vector(mse.m), nrow=nrow(K.grids), ncol=ncol(K.grids),
                  dimnames=list(corThr=rownames(K.grids), 
                                matchThr=colnames(K.grids)))
  corGrids <- as.numeric(rownames(K.grids))
  matchGrids <- as.numeric(colnames(K.grids))
  
  # find K that minimize MSE
  mse.min <- min(mse.m, na.rm=T)
  ind.min <- which(mse.m==mse.min, arr.ind=T)
  Krobust.min <- K.grids[ind.min][1] 
  
  # find K using 1-SE rule
  min.mse.se <- sd(mse.array[ind.min[1,1], ind.min[1,2], ], na.rm=T) #SD across iterations for the corThresh and matchThresh values that minimize the mean MSE across iterations
  mseThr <- mse.m[ind.min[1,1], ind.min[1,2]] + min.mse.se #mean MSE + SD
  K.grids.tmp <- K.grids
  K.grids.tmp[mse.m > mseThr | K.grids.tmp==0] <- NA #filter out any cor-match indices with higher mean MSE than the the min mean MSE + the min mean MSE's SD....
  Krobust.1se <- min(K.grids.tmp, na.rm=T)
  ind.1se <- which(K.grids.tmp == Krobust.1se, arr.ind=T)
  
  par.min <- cbind(corGrids[ind.min[,1]], matchGrids[ind.min[,2]], K.grids[ind.min])
  par.1se <- cbind(corGrids[ind.1se[,1]], matchGrids[ind.1se[,2]], K.grids[ind.1se])
  colnames(par.min) <- colnames(par.1se) <- c('opt.corThr', 'opt.matchThr', 'optK')
  
  return(list(mse.m=mse.m, mse.min=mse.min, 
              min.mse.se=min.mse.se, mseThr=mseThr,
              par.min=par.min, Krobust.min=Krobust.min,   ## min-MSE criterion
              par.1se=par.1se, Krobust.1se=Krobust.1se))  ## 1-SE criterion
}

##### Functions to extract robust factors #####
### 0. Using the GFA::gfa() resulting object to compute 
###    (1) posterior medians  
###    (2) credible interval limits
###    (3) factor-wise reconstratced data (i.e. X * W)
psSummary <- function(gfa.res, credible.lv){
  p.vec <- c((1-credible.lv)/2, 0.5, (1+credible.lv)/2)
  # dimensions = 3 (quantiles) x D x K
  tmp <- apply(gfa.res$posterior$W, 2:3, function(x) quantile(x, p.vec) )
  gfa.res$W.Summ <- list(lo=tmp[1,,], p50=tmp[2,,], hi=tmp[3,,])
  # dimensions = 3 (quantiles) x N x K
  tmp <- apply(gfa.res$posterior$X, 2:3, function(x) quantile(x, p.vec) )
  gfa.res$X.Summ <- list(lo=tmp[1,,], p50=tmp[2,,], hi=tmp[3,,])
  gfa.res$Yhat.p50 <- list()
  for (k in 1:dim(tmp)[3]){
    
    # JD edit start #
    # if only one factor, need to redefine gfa.res$X.Summ$p50 as a matrix
    if (dim(tmp)[3] == 1) {
      dummyX <- as.matrix(gfa.res$X.Summ$p50);
      dummyW <- as.matrix(gfa.res$W.Summ$p50);
    } else {
      dummyX <- gfa.res$X.Summ$p50;
      dummyW <- gfa.res$W.Summ$p50;
    }
    gfa.res$Yhat.p50[[k]] <- matrix(dummyX[,k], ncol=1) %*%
      matrix(dummyW[,k], nrow=1) # N x D
    # JD edit end #
    
    # replaced code start #
    # gfa.res$Yhat.p50[[k]] <- matrix(gfa.res$X.Summ$p50[,k], ncol=1) %*%
    # matrix(gfa.res$W.Summ$p50[,k], nrow=1) # N x D
    # replaced code end #
  
  }
  names(gfa.res$Yhat.p50) <- paste0("K", 1:length(gfa.res$Yhat.p50))
  out <- gfa.res[names(gfa.res) %in% c("K", "W.Summ", "X.Summ", "Yhat.p50")]
  return(out)
}

### Flip signs of factor loadings to ensure factors in the same direction across replicates
w.signs <- function(models, rob=indices, use.unmatched=F){
  indices <- abs(rob$indices)
  if (!use.unmatched){
    indices[rob$indices<0] <- 0
  }
  n.reps <- length(models)
  maxK <- ncol(indices)
  ref.rep <- which.min(apply(rob$indices<0, 1, sum))[1]
  rep.ind <- c(1:n.reps)[-ref.rep]
  for (r in rep.ind){

    # JD edit start #
    # hack for dealing with K.rob == 1, in which case models[[ref.rep]]$W.Summ$p50 only has one row
    # if (!is.null(dim(models[[ref.rep]]$W.Summ$p50))) { #if more than 1 robust factor ****************************************
    if (maxK > 1) {
      sign.tmp <- diag(sign(cor(models[[ref.rep]]$W.Summ$p50[, indices[ref.rep,]],
                                models[[r]]$W.Summ$p50[, indices[r,]])))
    } else { #if only 1 robust factor
      sign.tmp <- diag(as.matrix(sign(cor(models[[ref.rep]]$W.Summ$p50,
                                 models[[r]]$W.Summ$p50))))
    }
    # JD edit end #

    # replaced code start #
    # sign.tmp <- diag(sign(cor(models[[ref.rep]]$W.Summ$p50[, indices[ref.rep,]],
    #                           models[[r]]$W.Summ$p50[, indices[r,]])))
    # replaced code end #

    len.tmp <- length(sign.tmp) - maxK
    if(len.tmp<0){
      sign.tmp <- c(sign.tmp, rep(0, -len.tmp))
    } else if (len.tmp>0){
      sign.tmp <- sign.tmp[1:maxK]
    }
    indices[r, ] <- indices[r, ] * sign.tmp
    if (!use.unmatched){
      indices[indices==0] <- NA
    }
  }
  return(indices)
}

### a function to compute % variance explained
rob.var.exp <- function(models, indices, block.names, varIdx.by.block, use.unmatched=F, by.block=T){
  n.reps <- length(models)
  indices <- w.signs(models, rob=indices, use.unmatched)
  K.rob <- ncol(indices)

  # JD edit start #
  # hack for dealing with K.rob == 1
  if (K.rob != 1) {
    W.p50.rep <- array(NA, dim=c(nrow(models[[1]]$W.Summ$p50), K.rob, n.reps))
  } else {
    W.p50.rep <- array(NA, dim=c(length(models[[1]]$W.Summ$p50), K.rob, n.reps))
  }
  # JD edit end #

  # replaced code start #
  # W.p50.rep <- array(NA, dim=c(nrow(models[[1]]$W.Summ$p50), K.rob, n.reps))
  # replaced code end #

  for (r in 1:n.reps){
    idx_vec <- indices[r,]
    if (length(idx_vec)==1) {

      # JD edit start #
      # hack for dealing with K.rob == 1
      #if (!is.null(dim(a))) {
      if (!is.null(dim(models[[r]]$W.Summ$p50))) {
        W.p50.rep[,,r] <- sign(idx_vec)*models[[r]]$W.Summ$p50[, abs(idx_vec)]
      } else {
        W.p50.rep[,,r] <- sign(idx_vec)*models[[r]]$W.Summ$p50
      }
      # JD edit end #

      # replaced code start #
      # W.p50.rep[,,r] <- sign(idx_vec)*models[[r]]$W.Summ$p50[, abs(idx_vec)]
      # replaced code end #

    } else {

      # JD edit start #
      # hack to deal with cases in which idx_vec contains zeros or NAs
      signDummy <- sign(idx_vec);
      if (any(idx_vec == 0) | any(is.na(idx_vec) == TRUE))  {

        if (!is.na(any(idx_vec == 0))) {
          zeros <- which(idx_vec == 0)
          signDummy <-signDummy[-zeros]
        } else {
          zeros <- NULL;
        }
        if (any(is.na(idx_vec) == TRUE)) {
          NAs <- which(is.na(idx_vec) == TRUE)
          signDummy <-signDummy[-NAs]
        }

        if (is.null(dim(models[[r]]$W.Summ$p50))) {
          models[[r]]$W.Summ$p50 <- as.matrix(models[[r]]$W.Summ$p50);
        }

        sweepDummy <- sweep(as.matrix(models[[r]]$W.Summ$p50[, abs(idx_vec)]),
                                MARGIN=2, signDummy, '*')
        numRows <- dim(sweepDummy)[1];
        counter = 1;
        modData = matrix(, nrow = numRows, ncol = length(idx_vec))
        for (COL in 1:length(idx_vec)) {
          if (any(zeros == COL)) {
            modData[,COL] <- rep(0, numRows);
          } else {
            modData[,COL] = sweepDummy[,counter];
            counter = counter + 1;
          }
        }
        W.p50.rep[,,r] <- modData;
      } else {
        W.p50.rep[,,r] <- sweep(models[[r]]$W.Summ$p50[, abs(idx_vec)],
                              MARGIN=2, signDummy, '*')
      }
      # JD edit end #

      # replaced code start #
      # W.p50.rep[,,r] <- sweep(models[[r]]$W.Summ$p50[, abs(idx_vec)],
      #                         MARGIN=2, sign(idx_vec), '*')
      # replaced code end #
    }
  }
  ve.rep <- apply(W.p50.rep^2, 2:3, mean, na.rm=T)*100

  colnames(ve.rep) <- paste0('rep.', 1:n.reps)
  rownames(ve.rep) <- paste0('Component ', 1:K.rob)
  ve <- data.frame(matrix(NA, K.rob, 3))
  names(ve) <- c('Component', 'Mean', 'SE')
  ve$Component <- 1:K.rob
  ve$Mean <- apply(ve.rep, 1, mean, na.rm=T)
  ve$SE <- apply(ve.rep, 1, sd, na.rm=T)/sqrt(apply(!is.na(ve.rep), 1, sum))

  ve <- ve[order(-ve$Mean), ]
  ve <- within(ve, cum_var <- cumsum(ifelse(is.na(ve$Mean), 0, ve$Mean)))

  tot.ve.m <- mean(apply(W.p50.rep^2, 3, sum, na.rm=T))/dim(W.p50.rep)[1]*100
  tot.ve.s <- sd(apply(W.p50.rep^2, 3, sum, na.rm=T))/dim(W.p50.rep)[1]*100
  p <- ggplot(ve,
              aes(x=1:K.rob, y=Mean, ymin=Mean-SE, ymax=Mean+SE)) +
    geom_pointrange() +
    xlab('Robust components') + ylab('Percent variance explained') +
    theme_bw() # use a white background
  print(p + ggtitle(paste0('The ', K.rob, ' robust components explain ',
                           round(tot.ve.m,1), '+/-', round(tot.ve.s, 1),
                           '% variance of all variables')))

  # % variance explained by block
  if (by.block){
    nBlocks = length(block.names)
    ve.by.block <- ve.by.block.comp <- NULL # list()
    for (b in 1:nBlocks){
      ## variance explained by block by factor/component

      # JD edit start #
      # hack to deal with R automatically removing dimensions in "W.p50.rep" (which messes up the apply function) when there's either only one RF or only one variable
      dummy = dim(W.p50.rep);
      Krobust = dummy[2];
      numCurrVars <- length(varIdx.by.block[[b]])

      if (length(dim(W.p50.rep[varIdx.by.block[[b]],,])) < 3) {

        dummy1 = W.p50.rep[varIdx.by.block[[b]],,]^2; #dimensions will depend on which parameter (variable or RF) has only one instance
        if (numCurrVars == 1) {

          #ve.tmp dimensions = RFs x replicates (variables = 1 and its original dimension (1) gets removed -- unless there is only one RF, in which case you need to use as.matrix and transpose...)
          if (is.null(dim(dummy1))) { #if only one RF dummy will be a vector and the dim() function will return null (could also use is.vector)
            dummy1 <- t(as.matrix(dummy1))
          }
          ve.tmp <- dummy1; #dummy 1 is already in the robust factors x replicates format that we want

        } else

          #ve.tmp dimensions = variables x replicates (RF = 1 and its original dimension (2) gets removed)
          ve.tmp <- t(as.matrix(apply(dummy1, 2, mean, na.rm=T)*100)) #take the mean across variables and get a robust factors by replicates matrix
      } else {
        ve.tmp <- apply(W.p50.rep[varIdx.by.block[[b]],,]^2, 2:3, mean, na.rm=T)*100 #take the mean across variables and get a robust factors by replicates matrix
      }
      # JD edit end #

      # replaced code start #
      # ve.tmp <- apply(W.p50.rep[varIdx.by.block[[b]],,]^2, 2:3, mean, na.rm=T)*100
      # replaced code end #

      colnames(ve.tmp) <- paste0('rep.', 1:n.reps)
      rownames(ve.tmp) <- paste0('Component ', 1:K.rob)
      ve.comps <- data.frame(matrix(NA, K.rob, 3))
      names(ve.comps) <- c('Component', 'Mean', 'SE')
      ve.comps$Component <- 1:K.rob
      ve.comps$Mean <- apply(ve.tmp, 1, mean, na.rm=T)
      ve.comps$SE <- apply(ve.tmp, 1, sd, na.rm=T)/sqrt(apply(!is.na(ve.tmp), 1, sum))
      ve.comps$Block <- block.names[b]
      ve.by.block.comp <- rbind(ve.by.block.comp, ve.comps)

      ## variance explained by block

      # JD edit start #
      # similar edit to the one above to deal with dimensionality reduction messing up the apply function
      if (length(dim(W.p50.rep[varIdx.by.block[[b]],,])) < 3) {#jd hack
        ve.tmp <- apply(dummy1, 2, sum, na.rm=T)/
          length(varIdx.by.block[[b]])
      } else {
        ve.tmp <- apply(W.p50.rep[varIdx.by.block[[b]],,]^2, 3, sum, na.rm=T)/
          length(varIdx.by.block[[b]]) #sum of entire variable x robust factor matrix for each replicate
      }
      # JD edit end #

      # replaced code start #
      # ve.tmp <- apply(W.p50.rep[varIdx.by.block[[b]],,]^2, 3, sum, na.rm=T)/
      #   length(varIdx.by.block[[b]])
      # replaced code end #

      m <- mean(ve.tmp)*100
      s <- sd(ve.tmp)/sqrt(n.reps)*100
      ve.by.block <- rbind(ve.by.block, c(m, s))
    }
    ve.by.block.comp$Block <- as.factor(ve.by.block.comp$Block)
    ve.by.block.comp$Block <- factor(ve.by.block.comp$Block, levels=block.names)
    ve.by.block.comp <- ve.by.block.comp[, c('Block', 'Component', 'Mean', 'SE')]

    ve.by.block <- data.frame(Block=block.names, ve.by.block)
    names(ve.by.block)[-1] <- c("Mean", "SE")

    return(list(
      indices=indices,
      ve=ve.rep,                 ## (Krobust x n.Reps): varaince explained (ve) per factor per replicate
      ve.summ=ve,                ## (Krobust rows): Mean and SE of ve per factor
      ve.by.block.comp=ve.by.block.comp, ## (Krobust x nBlocks rows): ve by block by factor
      ve.by.block=ve.by.block))  ## (nBlock rows): ve per block
  } else {
    return(list(indices=indices, ve=ve.rep, ve.summ=ve))
  }
}

### a function to compute robust loadings and robust scores
rob_wx <- function(models, indices, block.labs, var.labs=NULL){
  
  # JD edit start #
  # adding as.matrix() to lines below to prevent breaking when Krobust == 1
  N <- nrow(as.matrix(models[[1]]$X.Summ$p50))
  if("W.Summ" %in% names(models[[1]])){
    D <- nrow(as.matrix(models[[1]]$W.Summ$p50))
  } else if ("W" %in% names(models[[1]])){
    D <- nrow(as.matrix(models[[1]]$W))
  }
  # JD edit end #
  
  # replaced code start #
  # N <- nrow(models[[1]]$X.Summ$p50)
  # if("W.Summ" %in% names(models[[1]])){
  #   D <- nrow(models[[1]]$W.Summ$p50)
  # } else if ("W" %in% names(models[[1]])){
  #   D <- nrow(models[[1]]$W)
  # }
  # replaced code end #
  
  n.reps <- length(models)
  Krobust <- ncol(indices)
  
  # create a dataframe to store credible intervals of loadings across replicates
  # Henry edited on 2018-12-12: Add block names and preferred variable names 
  
  # JD edit start #
  # hack to deal with Krobust == 1
  # if (Krobust > 1) { ##commented out 5/28/20
    df.base <- data.frame(Block=block.labs,
                          #Variable=rownames(models[[1]]$W.Summ$p50),
                          Variable=rownames(as.data.frame(models[[1]]$W.Summ$p50)),
                          var.lab=var.labs,
                          var.order=as.numeric(1:length(var.labs)))
  # } else { ##commented out 5/28/20
    # df.base <- data.frame(Block=block.labs,  ##commented out 5/28/20
    #                       Variable=names(models[[1]]$W.Summ$p50),  ##commented out 5/28/20
    #                       var.lab=var.labs,  ##commented out 5/28/20
    #                       var.order=as.numeric(1:length(var.labs)))  ##commented out 5/28/20
  # } ##commented out 5/28/20
  # JD edit end #
  
  # replaced code start #
  # df.base <- data.frame(Block=block.labs, 
  #                       Variable=rownames(models[[1]]$W.Summ$p50), 
  #                       var.lab=var.labs, 
  #                       var.order=as.numeric(1:length(var.labs)))
  # replaced code end #
  
  w.ci <- df.base[rep(seq_len(nrow(df.base)), n.reps*Krobust),]
  w.ci$Replicate <- rep(1:n.reps, each=D*Krobust)
  w.ci$Component <- rep(rep(1:Krobust, each=D), n.reps)
  w.ci <- w.ci[, c('Replicate', 'Component', 'Block', 'Variable', 'var.lab', 'var.order')]
  w.ci$Upper <- w.ci$Median <- w.ci$Lower <- 0
  
  # Extract posterior medians and credible intervals for loadings in each replicate
  for (r in 1:n.reps){
    for (k in 1:Krobust){
      
      # JD edit start #
      # hack to deal with Krobust == 1
      if (!is.na(indices[r,k]) & indices[r,k] != 0) {
        
        if (Krobust > 1) {
          w.ci[w.ci$Replicate==r & w.ci$Component==k, c('Lower', 'Median', 'Upper')] <-
            sign(indices[r,k]) *
            do.call(cbind, lapply(models[[r]]$W.Summ, function(x) x[, abs(indices[r,k])]))
        } else {
          w.ci[w.ci$Replicate==r & w.ci$Component==k, c('Lower', 'Median', 'Upper')] <-
            sign(indices[r,k]) *
            do.call(cbind, models[[r]]$W.Summ)
        }
      }
      if (!is.na(indices[r,k]) & indices[r,k] != 0){ # hack to deal with NA values in "indices"
        if (sign(indices[r,k])==-1) {
          w.ci[w.ci$Replicate==r & w.ci$Component==k, c('Lower', 'Upper')] <-
            w.ci[w.ci$Replicate==r & w.ci$Component==k, c('Upper', 'Lower')]
        }
      }
      # JD edit end #
      
      # replaced code start #
      # w.ci[w.ci$Replicate==r & w.ci$Component==k, c('Lower', 'Median', 'Upper')] <- 
      #   sign(indices[r,k]) * 
      #   do.call(cbind, lapply(models[[r]]$W.Summ, function(x) x[, abs(indices[r,k])]))
      # if(sign(indices[r,k])==-1){
      #   w.ci[w.ci$Replicate==r & w.ci$Component==k, c('Lower', 'Upper')] <- 
      #     w.ci[w.ci$Replicate==r & w.ci$Component==k, c('Upper', 'Lower')]
      # }
      # replaced code end #
    }
  }
  # Henry edited 2018-08-27: change "w.ci$Lower==0 & w.ci$Upper==0" to "|"
  w.ci$contain.0 <- (w.ci$Lower * w.ci$Upper < 0 | w.ci$Lower==0 | w.ci$Upper==0)*1
  
  # compute medians of posterior medians and credible interval limits across replicates
  w.ci.med <- df.base[rep(seq_len(nrow(df.base)), Krobust),]
  w.ci.med$Component <- rep(1:Krobust, each=D)
  w.ci.med <- w.ci.med[, c('Component', 'Block', 'Variable', 'var.lab', 'var.order')]
  tmp <- aggregate(Lower  ~ Component + var.order, median, data=w.ci)
  w.ci.med <- merge(w.ci.med, tmp, by=c('Component', 'var.order'))
  tmp <- aggregate(Median ~ Component + var.order, median, data=w.ci)
  w.ci.med <- merge(w.ci.med, tmp, by=c('Component', 'var.order'))
  tmp <- aggregate(Upper  ~ Component + var.order, median, data=w.ci)
  w.ci.med <- merge(w.ci.med, tmp, by=c('Component', 'var.order'))
  
  w.ci.med <- w.ci.med[with(w.ci.med, order(w.ci.med$Component, w.ci.med$var.order)), 
                       c('Component', 'Block', 'Variable', 'var.lab', 
                         'var.order', 'Lower', 'Median', 'Upper')]
  # Henry edited 2018-08-27: change "w.ci$Lower==0 & w.ci$Upper==0" to "|"
  w.ci.med$contain.0 <- (w.ci.med$Lower * w.ci.med$Upper < 0 | 
                           w.ci.med$Lower==0 | w.ci.med$Upper==0)
  w.ci.med$all.0 <- (w.ci.med$Lower==0 & w.ci.med$Upper==0)*1
  
  # compute median (across replicates) of poseterior medians if the credible interval excludes 0 
  w.med <- matrix(w.ci.med$Median*(1-w.ci.med$contain.0), D, Krobust)
  colnames(w.med) <- 1:Krobust
  rownames(w.med) <- var.labs # rownames(models[[1]]$W)
  
  # jd addition start #
  # compute median (across replicates) of poseterior medians for all factors
  w.med.all <- matrix(w.ci.med$Median, D, Krobust)
  colnames(w.med.all) <- 1:Krobust
  rownames(w.med.all) <- var.labs # rownames(models[[1]]$W)
  # jd addition end #
  
  # compute the medians (across replicates) of posterior medians of factor scores 
  x.rep <- array(NA, dim=c(N, Krobust, n.reps))
  for (r in 1:n.reps){
    
    # JD edit start #
    # hack to deal with Krobust == 1
    indDummy = which(!is.na(abs(indices[r,])));
    
    if (Krobust > 1) {
      x.rep[,which(abs(indices[r,]) != 0),r] <- models[[r]]$X.Summ$p50[, abs(indices[r,indDummy])]
    } else {
      dummy = as.matrix(models[[r]]$X.Summ$p50);
      x.rep[,which(abs(indices[r,]) != 0),r] <- dummy[, abs(indices[r,indDummy])]
    }
    x.rep[,,r] <- sweep(as.matrix(x.rep[,,r]), MARGIN=2, sign(indices[r,]), '*') #added the as.matrix() operation to deal with Krobust == 1
    # JD edit end #
    
    # replaced code start #
    # x.rep[,,r] <- models[[r]]$X.Summ$p50[, abs(indices[r,])]
    # x.rep[,,r] <- sweep(x.rep[,,r], MARGIN=2, sign(indices[r,]), '*')
    # replaced code end #
  }
  x.rob <- apply(x.rep, 1:2, median, na.rm=T)
  colnames(x.rob) <- paste0('K', 1:Krobust)
  return(list(w.ci=w.ci, w.ci.med=w.ci.med, w.med=w.med, w.med.all=w.med.all, x.rob=x.rob))
}

### 4a. a base function to create a heat map
w.plot <- function(w, D, K, gr1, conf.level, replicate, factorNames = 1:dim(w)[2], varNames = 1:D){
  mar <- c(8,6,4,6)
  par(mar=mar)
  
  # jd edit start #
  grain = 301 #using this to set grain on color bar
  # jd edit end #
  
  # cols <- colorRampPalette(c("orange","red","white","blue","cyan"))(grain)
  # if(any(is.na(w))) cols <- colorRampPalette(c("orange","red","#DDDDDD","blue","cyan"))(grain)
  cols <- colorRampPalette(c("blue","cyan","white","orange","red"))(grain)
  if(any(is.na(w))) cols <- colorRampPalette(c("cyan","blue","#DDDDDD","red","orange"))(grain)
  M <- max(abs(w),na.rm=T)
  breaks <- seq(-M,M,length=grain + 1)
  
  title <- c("Matrix W^T","Components"," ") #jd edit to remove "Features" label from x-axis
  if (!is.null(replicate)){
    title[1] <- paste0('Replicate ', replicate,': ', title[1])
  } else {
    if (is.null(conf.level)){
      title[1] <- paste0(title[1], ' (all components & ', round(sum(w!=0)), ' loadings)')
    } else if (!is.null(conf.level)){
      title[1] <- paste0(title[1], ' (', sum(w!=0),' non-zero loadings at ', conf.level*100, '% confidence)')
    }
  }
  
  # if (K==1){
  #   image(1:D, 1:K, as.matrix(w[,1]), col=cols, breaks=breaks, axes=FALSE, main=title[1],
  #         xlab="", ylab="") #jd edit: changed axes=F to axes=FALSE to suppress default tick labels
  # } else {
    image(1:D, 1:K, as.matrix(w[,K:1]), col=cols, breaks=breaks, axes=FALSE, main=title[1],
          xlab="",ylab="") #jd edit: changed axes=F to axes=FALSE to suppress default tick labels
  # }
  title(xlab=title[3],line=mar[1]-1)
  #title(ylab=title[2],line=mar[2]-1)
  box()
  par(las=2)
  axis(1, 1:D, rep("",D), cex.axis=D^(-1/5))
  if (length(varNames) > 30) { #really arbitrary but time is of the essence...
    axis(1, at=seq(2,floor(D/2)*2,2), seq(2,floor(D/2)*2,2), cex.axis=(floor(D/2)*2)^(-1/10)) 
  } else {
    axis(1, at=1:length(varNames), varNames, cex.axis=(floor(D/2)*2)^(-1/10))
  }
  axis(2, K:1, factorNames, cex.axis=K^(-1/5)) 
  
  #Grouping
  par(xpd=T)
  mu <- gr1[-1]/2+gr1[-length(gr1)]/2
  N <- K
  for(i in 1:length(mu)) {
    if (K == 1) {
      if(i!=length(mu)) lines(rep(gr1[i+1]+1/2,2), c(0.6,1.4), lwd=2)
    } else {
      if(i!=length(mu)) lines(rep(gr1[i+1]+1/2,2), c(.5, N*1.03+.5), lwd=2)
    }
    #text(mu[i],N*1.03+.5,names(gr1)[i],srt = 15) #jd edit: add srt input to tilt group names
  }
  #Colorbar
  n <- length(cols)
  
  cba <- D + 1/2 + D/60
  cbw <- D/40
  if (K==1){
    SF = 0.8;
    for(i in 1:n){
      polygon(c(0,cbw,cbw,0)+cba, c(0,0,(N/n)*SF,(N/n)*SF)+(N*(i-1)/n)*SF+(1/2)*(2-SF),
              col=cols[i], border=NA)
    }
    #Colorbar: axis
    lines(rep(cba+cbw,2),c(0.6,1.4))
    m <- 10^floor(log10(M)); m <- floor(M/m)*m
    for(l in c(-m,0,m)) {
      ly <- (N*(l/M*SF/2+.5)+1/2)
      lines(cba+cbw-c(cbw,-cbw)/5, rep(ly,2))
      text(cba+cbw*2.5,ly,l)
    }
    
  } else {
    for(i in 1:n){
      polygon(c(0,cbw,cbw,0)+cba, c(0,0,N/n,N/n)+N*(i-1)/n+1/2,
              col=cols[i], border=NA)
    }
    #Colorbar: axis
    lines(rep(cba+cbw,2),c(0,N)+1/2)
    m <- 10^floor(log10(M)); m <- floor(M/m)*m
    for(l in c(-m,0,m)) {
      ly <- N*(l/M/2+.5)+1/2
      lines(cba+cbw-c(cbw,-cbw)/5, rep(ly,2))
      text(cba+cbw*2.5,ly,l)
    }
  }
  par(xpd=F)
}

### 4b. a function to produce a heatmap for robust factor loadings
gfa_heatmap <- function(robW, block.names, varIdx.by.block, conf.level, heatmap.rep=FALSE, factor.order=NULL, varNames = NULL){
  if (is.null(varNames)) {
    varNames = 1:nrow(robW$w.med)
  }
  
  n.rep <- max(robW$w.ci$Replicate)
  # heat maps
  gr <- varIdx.by.block; M <- length(gr)
  if (is.null(block.names)) { 
    names(gr) <- paste("Source",1:M) 
  } else { names(gr) <- block.names }
  gr1 <- c(0,cumsum(sapply(gr, length))); names(gr1) <- c(names(gr), "NA")
  if (n.rep > 1 & heatmap.rep){
    for (r in 1:n.rep){
      w.tmp <- matrix(robW$w.ci$Median[robW$w.ci$Replicate==r]*(1-robW$w.ci$contain.0[robW$w.ci$Replicate==r]), 
                      nrow(robW$w.med), ncol(robW$w.med))
      colnames(w.tmp) <- 1:ncol(robW$w.med)
      rownames(w.tmp) <- rownames(robW$w.med)
      w.plot(w.tmp, D=nrow(w.tmp), K=ncol(w.tmp), gr1, conf.level, r, factorNames=robW$ve_labels) 
    }
  }
  # print('Robust heat map')
  if(!is.null(factor.order)){
    w.plot(robW$w.med[, factor.order], D=nrow(robW$w.med), K=ncol(robW$w.med), gr1, conf.level, replicate=NULL, factorNames=robW$ve_labels) 
  } else {
    #start jd hack to get variable names in plot
    rowCounter <- 1
    for (LIST in 1:length(gr)) {
      for (VAR in 1:length(gr[[LIST]])) {
        rownames(robW$w.med)[rowCounter] <- gr[[LIST]][VAR]
        rowCounter = rowCounter + 1;
      }
    }
    
    #end jd hack to get variable names in plot
    w.plot(w=robW$w.med, D=nrow(robW$w.med), K=ncol(robW$w.med), gr1, conf.level, replicate=NULL, factorNames=robW$ve_labels, varNames) 
  }
}

#find r that gets Nthresh as close to 1 as possible
optCorrThresh <- function(r,n,k) {
  
  t=r*sqrt((n-2)/(1-r^2))
  p=2*(1 - pt(t, n-2))
  numCoeffs=k*(k-2)/2
  Nthresh = numCoeffs*p
  return(abs(Nthresh-1))
}

# HY editted on 2019-4-2 to allow setting upper and lower limits
Circbar <- function(mydata, ebar, graphtitle, textlabel, minx, maxx){
  
  data <- mydata
  labelsize <- textlabel
  
  # Assign min and max
  mymin <- ifelse(-1.5 + min(mydata$Lower) < -2,-1.5 + min(mydata$Lower),-2)
  mymax <- ifelse(1 + max(mydata$Upper) < 1, 1, 1 + max(mydata$Upper))
  
  # Set the level lines
  if (is.null(minx)){
    ifelse(min(mydata$Lower) < -.1, minx <- min(mydata$Lower), minx <- -.1)
    ifelse(min(mydata$Upper) < minx, minx <- min(mydata$Upper), minx <- minx)
  }
  if(is.null(maxx)){
    ifelse(max(mydata$Upper) > .1, maxx <- max(mydata$Upper), maxx <- .1)
    ifelse(max(mydata$Lower) > maxx, maxx <- max(mydata$Lower), maxx <- maxx)
  }
  
  # Set a number of 'empty bar' to add at the end of each group
  empty_bar <- ebar
  
  to_add = data.frame( matrix(NA, empty_bar*nlevels(data$GFAblocks), ncol(data)) )
  colnames(to_add) = colnames(data)
  to_add$GFAblocks=rep(levels(data$GFAblocks), each=empty_bar)
  data=rbind(data, to_add)
  data=data %>% arrange(GFAblocks)
  data$id=seq(1, nrow(data))
  
  # Get the name and the y position of each label
  label_data=data
  number_of_bar=nrow(label_data)
  angle= 90 - 360 * (label_data$id-0.5) /number_of_bar     # I substract 0.5 because the letter must have the angle of the center of the bars. Not extreme right(1) or extreme left (0)
  label_data$hjust<-ifelse( angle < -90, 1, 0)
  label_data$angle<-ifelse(angle < -90, angle+180, angle)
  
  # prepare a data frame for base lines
  
  base_data=data %>% 
    group_by(GFAblocks) %>% 
    dplyr::summarize(start=min(id), end=max(id) - empty_bar) %>% 
    rowwise() %>% 
    mutate(Title=mean(c(start, end)))
  
  # prepare a data frame for grid (scales)
  grid_data = base_data
  grid_data$end = grid_data$end[ c( nrow(grid_data), 1:nrow(grid_data)-1)] + 1
  grid_data$start = grid_data$start - 1
  #grid_data=grid_data[-1,]
  
  # Make the plot
  p = ggplot(data, aes(x=as.factor(id), y=Median, fill=GFAblocks)) +       
    # Note that id is a factor. If x is numeric, there is some space between the first bar
    
    geom_bar(aes(x=as.factor(id), y=Median, fill=GFAblocks), stat="identity", alpha=0.5)  +
    geom_errorbar(aes(x=as.factor(id),ymin=Lower,ymax=Upper,color="Gray")) +
    
    # Add a level lines.
    geom_segment(data=grid_data, aes(x = end, y = minx, xend = start, yend = minx), colour = "grey", alpha=1, size=0.3 , inherit.aes = FALSE ) + 
    geom_segment(data=grid_data, aes(x = end, y = 0, xend = start, yend = 0), colour = "grey", alpha=1, size=0.3 , inherit.aes = FALSE ) + 
    geom_segment(data=grid_data, aes(x = end, y = maxx, xend = start, yend = maxx), colour = "grey", alpha=1, size=0.3 , inherit.aes = FALSE )
  
  # Add text showing the value of each level lines
  p = p + annotate("text", x = rep(max(data$id),3), y = c(minx,0, maxx), label = format(c(minx,0, maxx),digits=2) , color="black", size=3 , angle=0, fontface="bold", hjust=1) +
    
    ylim(mymin,mymax) +
    theme_minimal() +
    theme(
      legend.position = "none",
      axis.text = element_blank(),
      axis.title = element_blank(),
      panel.grid = element_blank(),
      plot.margin = unit(rep(-1,4), "cm")
    ) +
    coord_polar() +
    geom_text(data=label_data, aes(x=id, y=mymax-.9, label=GFAvarlabs, hjust=hjust), color="black", fontface="bold",alpha=0.6, size=labelsize, angle= label_data$angle, inherit.aes = FALSE )  +
    
    # Add base line information
    geom_segment(data=base_data, aes(x = start, y = -1.1 , xend = end, yend = -1.1, colour=GFAblocks), alpha=0.8, size=1 , inherit.aes = FALSE )  +
    
    geom_segment(data=base_data, aes(x = start, y = 0 , xend = end, yend = 0), colour = "Gray", alpha=0.8, size=0.6 , inherit.aes = FALSE )  +
    
    geom_text(data=grid_data, aes(x = Title, y = -1.3, label=GFAblocks),color="black", fontface="bold") +
    
    annotate("text", x = 0, y = -1.8, label = c(graphtitle) , color="red", size=4 , fontface="bold")
  
  return(p)
  
}
